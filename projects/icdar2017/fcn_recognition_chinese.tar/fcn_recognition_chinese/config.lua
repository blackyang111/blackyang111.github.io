--- All parameters goes here
local config = config or {}

function config.parse(arg)
	local cmd = torch.CmdLine()
	cmd:text()
	cmd:text('Adaptive classification')
	cmd:text()
	-- Parameters
    -- data loader
    cmd:option('-prefix', 'synthetic_caption_', 'prefix: dataset name')
    cmd:option('-max_height', 64, 'img max height')
	cmd:option('-pixel_means', {0.5, 0.5, 0.5}, 'Pixel mean values (RGB order)')

    cmd:option('-h5_path', './data/', 'path to h5')
    cmd:option('-h5_list_train_path', './data/h5_list_train.txt', 'txt file containing a list of h5 for training')
    cmd:option('-h5_list_val_path', './data/h5_list_val.txt', 'txt file containing a list of h5 for validation')
    cmd:option('-h5_list_test_path', './data/h5_list_competition.txt', 'txt file containing a list of h5 for testing')

    cmd:option('-char_list_path', './Chinese3755-list.txt', 'list of chars')

    -- training
    cmd:option('-gpuid', 1, 'gpu id')
    cmd:option('-nb_epoch', 10, 'number of epoches')
    cmd:option('-batch_size', 64, 'batch size')
    cmd:option('-c1out', 512, 'c1out')
	cmd:option('-out_path','./exp', 'output path')
	cmd:option('-teacher_force', 0, 'output path')
    cmd:option('-dropout', 0.2, 'dropout')

    cmd:option('-decoder_type', 'att', 'decoder type: att, noatt, mlp')

    -- optimizer
    cmd:option('-optimizer', 'adadelta', 'parameters of optimizer')
    cmd:option('-rho', 0.3, 'parameters of optimizer')
    cmd:option('-eps', 1e-6, 'parameters of optimizer')
    cmd:option('-learningRate', 1e-3, 'parameters of optimizer')
    cmd:option('-learningRateMin', 1e-7, 'parameters of optimizer')
    cmd:option('-momentum', 0.9, 'parameters of optimizer')
    cmd:option('-lr_decay', 1, 'iterations between lr decreses')
    cmd:option('-lr_decay_t', 5, 'lr decay times')

    -- resume
    cmd:option('-resume_training_trainable', 0, 'whether resume training')
    cmd:option('-saved_models', '', 'saved models')

    cmd:option('-resume_training', 0, 'whether resume training')
    cmd:option('-saved_model_weights', '', 'saved model weights')

    cmd:option('-resume_training_optim', 0, 'whether resume training')
    cmd:option('-saved_optim_state', '', 'saved optim state')

    cmd:option('-resume_training_encoder', 0, 'whether resume training')
    cmd:option('-saved_encoder_weights', '', 'saved encoder weights')

    -- save/print/log
	cmd:option('-snapshot_iters', 20000, 'Iterations between snapshots (used for saving the network)')
    cmd:option('-snapshot_iters_start', 1, 'number of iteration where we start from')
	cmd:option('-print_iters', 100, 'Iterations between print')
	cmd:option('-log_iters', 10, 'Iterations between log')
	cmd:option('-vis_iters', 1000, 'Iterations between visualization')

    -- decode
    cmd:option('-beam_size', 3, 'beam size')
    cmd:option('-decode_max_len', 5, 'decode max len')
    cmd:option('-eos_symbol', 1, 'eos symbol')
    cmd:option('-knowledge_distill', 1, 'knowledge distill')
    cmd:option('-knowledge_distill_grad', 0, 'knowledge distill grad')

    cmd:option('-debugMode', 0, 'debug mode (print every batch)')

	-- Parsing the command line 
	config = cmd:parse(arg or {})

    -- optim state
    config.optim_state = {rho = config.rho, eps = config.eps, learningRate = config.learningRate,
                          learningRateMin = config.learningRateMin, momentum = config.momentum}

    -- hdf5
    config.h5_list_train = {}
    for line in io.lines(config.h5_list_train_path) do
        table.insert(config.h5_list_train, line)
    end
    config.h5_list_val = {}
    for line in io.lines(config.h5_list_val_path) do
        table.insert(config.h5_list_val, line)
    end
    config.h5_list_test = {}
    for line in io.lines(config.h5_list_test_path) do
        table.insert(config.h5_list_test, line)
    end

    -- chars
    config.chars= {}
    for line in io.lines(config.char_list_path) do
        table.insert(config.chars, line)
    end

	return config
end

return config
