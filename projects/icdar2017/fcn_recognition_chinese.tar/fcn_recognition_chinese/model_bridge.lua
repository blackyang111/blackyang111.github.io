require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'

local function create_model(c1out)
    local model = nn.Sequential()

    model:add(nn.Transpose({2, 3}, {3, 4}))
    model:add(nn.View(-1, c1out):setNumInputDims(3))
    return model
end

return create_model
