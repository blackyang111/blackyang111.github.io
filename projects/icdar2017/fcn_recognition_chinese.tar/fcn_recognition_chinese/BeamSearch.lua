
local BeamSearch = torch.class('BeamSearch')

function BeamSearch:__init(beamSize, maxLength, eosSymbol) --, unknownSymbol)
    -- parent.__init(self)
    self.beamSize = beamSize
    self.maxLength = maxLength
    self.startSymbol = eosSymbol
    self.endSymbol = eosSymbol
    self.unknownSymbol = -1
end

function BeamSearch:search(dec, inputFunc, stateFunc, copyFunc)
    assert(dec.sharedClone, "Only use beam search with modules that support sharedClone")
    dec:forget()
    dec:remember('neither')

    local completeHypo = {}

    -- initialize bin
    local bin = {}
    local hypo0 = {y = {self.startSymbol}, cost = 0.0, prevState = nil, attentions = {}}
    bin[0] = {hypo0}

    for t = 1, self.maxLength do
        collectgarbage()

        -- check the previous bin
        local prevBin = bin[t-1]
        local buffHypo = {}
        local prePrune = nil

        for _, hypo in pairs(prevBin) do
            -- forget
            dec.step = 1

            local y = hypo.y[#hypo.y] -- take the last element
            y = inputFunc(y)

            -- decoder
            dec.userPrevOutput = hypo.prevState
            local out = dec:forward(y)
            local att = dec.attention_out:clone()
            local hidden = dec.output:clone()

            -- add to beam
            local val, id = torch.sort(out, true)
            if prePrune == nil then
                assert(id:size(2) >= self.beamSize, "Beam size bigger than vocabulary")
                prePrune = val[1][self.beamSize]
            else
                prePrune = math.max(prePrune, val[1][self.beamSize])
            end

            for j = 1, self.beamSize do
                local yn = id[1][j]
                local logp = val[1][j]
                -- Preprune
                if prePrune > logp then
                    break
                end

                local ys = {}
                for _, v in pairs(hypo.y) do ys[#ys+1] = v end
                ys[#ys+1] = yn
                local atts = {}
                for _, v in pairs(hypo.attentions) do atts[#atts+1] = v:clone() end
                atts[#atts+1] = att

                local newHypo = {y = ys, prevState = nil, cost = hypo.cost + logp, attentions = atts}
                if yn ~= self.endSymbol then
                    newHypo.prevState = hidden
                else
                    newHypo.prevState = nil
                    -- newHypo.cost = hypo.cost + logp * 1.2 -- penalty for early stop
                    completeHypo[#completeHypo + 1] = newHypo
                end
                if yn ~= self.unknownSymbol then
                    buffHypo[#buffHypo + 1] = newHypo
                end
            end
            hypo.prevState = nil
        end

        -- pruning
        table.sort(buffHypo, function(h1, h2)
            return h1.cost > h2.cost
        end)
        if #buffHypo == 0 then break end
        bin[t] = {}
        for j = 1, math.min(self.beamSize,#buffHypo) do
            bin[t][j] = buffHypo[j]
        end

        -- debug
        -- print('--------')
        -- print(t)
        -- print(bin[#bin])
    end

    local last_bin = bin[#bin]
    for _, hypo in pairs(last_bin) do
        hypo.prevState = nil -- Cleanup
        table.insert(completeHypo, hypo)
    end

    table.sort(completeHypo, function(h1, h2)
        return h1.cost > h2.cost
    end)
    -- print(completeHypo)
    local best_hypo = completeHypo[1]
    return best_hypo
end
