require 'hdf5'

local BatchIterator_hdf5 = torch.class('BatchIterator_hdf5')

function BatchIterator_hdf5:__init(config)
    self.batch_size = config.batch_size or 128
    self.pixel_means = config.pixel_means or {0, 0, 0}

    self.fullpass = false

    self.h5_path = config.h5_path

    -- self.train = {h5_list, idx_h5, order_h5, idx_batch, order_batch}
    self.train = {h5_list = config.h5_list_train}
    self.val = {h5_list = config.h5_list_val}
    self.test = {h5_list = config.h5_list_test}
end

function BatchIterator_hdf5:setBatchSize(batch_size)
    self.batch_size = batch_size or 128
end

function BatchIterator_hdf5:nextBatch(set)
    -- debug
    -- print('\tidx_h5: ' .. (self[set].idx_h5 or 'nil'))
    -- if self[set].order_h5 then
    --     print('\torder_h5: ' .. self[set].order_h5:view(1, self[set].order_h5:size(1)):__tostring__())
    -- else
    --     print('\torder_h5: nil')
    -- end
    -- print('\tidx_batch: ' .. (self[set].idx_batch or 'nil'))
    -- if self[set].order_batch then
    --     print('\torder_batch: ' .. self[set].order_batch[1])
    -- else
    --     print('\torder_batch: nil')
    -- end

    -- randomly select h5
    if not self[set].idx_h5 then -- first h5
        self[set].idx_h5 = 1
        self[set].order_h5 = torch.randperm(#self[set].h5_list)
        local idx_h5 = self[set].order_h5[self[set].idx_h5]

        local fin = hdf5.open(self.h5_path .. self[set].h5_list[idx_h5])
        self[set].data_x = fin:read('data_x'):all()
        self[set].data_y = fin:read('data_y'):all()
        fin:close()

        self[set].idx_batch = self.batch_size
        self[set].order_batch = torch.randperm(self[set].data_x:size(1))
    else
        if self[set].idx_batch > self[set].data_x:size(1) then -- load new h5
            self[set].idx_h5 = self[set].idx_h5 + 1
            if self[set].idx_h5 > #self[set].h5_list then -- finished one pass of all h5
                self.fullpass = true
                self[set].idx_h5 = 1
                self[set].order_h5 = torch.randperm(#self[set].h5_list)
            end

            local idx_h5 = self[set].order_h5[self[set].idx_h5]

            local fin = hdf5.open(self.h5_path .. self[set].h5_list[idx_h5])
            self[set].data_x = fin:read('data_x'):all()
            self[set].data_y = fin:read('data_y'):all()
            fin:close()

            self[set].idx_batch = self.batch_size
            self[set].order_batch = torch.randperm(self[set].data_x:size(1))
        end
    end

    -- randomly select batch
    assert(self[set].data_x:dim() == 4, 'data_x should be 4-D tensor')
    assert(self[set].data_y:dim() == 1, 'data_y should be 1-D tensor')

    local batch = {}
    batch.inputs = torch.Tensor(self.batch_size, self[set].data_x:size(2), self[set].data_x:size(3), self[set].data_x:size(4)):zero()
    batch.targets = torch.Tensor(self.batch_size):zero()

    local batch_start = self[set].idx_batch - self.batch_size

    for i = 1, self.batch_size do
        batch.inputs:select(1, i):copy(self[set].data_x:select(1, self[set].order_batch[batch_start + i]))
        batch.targets[i] = self[set].data_y:select(1, self[set].order_batch[batch_start + i])
    end

    -- update
    self[set].idx_batch = self[set].idx_batch + self.batch_size

    -- return
    return batch
end
