local utilities = {}

function utilities.load_obj(file_name)
  local f = torch.DiskFile(file_name, 'r')
  local obj = f:readObject()
  f:close()
  return obj
end

function utilities.convert2img(outputs, colors)
    -- outputs: bz * ch * h * w
    local h, w = outputs:size(3), outputs:size(4)
    local img = torch.Tensor(3, h, w):zero()

    local values, classes = torch.max(outputs, 2)

    for y = 1, h do
        for x = 1, w do
            local class = classes[{1, 1, y, x}]
            local prob = values[{1, 1, y, x}]
            for ch = 1, 3 do
                img[{ch, y, x}] = colors[class][ch] * prob
            end
        end
    end
    return img
end
function utilities.convert4crf(outputs, colors)
    -- outputs: bz * ch * h * w
    local h, w = outputs:size(3), outputs:size(4)
    local img = torch.Tensor(3, h, w):zero()
    local map = outputs:clone():permute(1, 2, 4, 3):contiguous():log()

    local values, classes = torch.max(outputs, 2)
    local confidence = values[1][1]:clone():mul(-1):add(1)

    for y = 1, h do
        for x = 1, w do
            local class = classes[{1, 1, y, x}]
            local prob = values[{1, 1, y, x}]
            for ch = 1, 3 do
                img[{ch, y, x}] = colors[class][ch] * prob
            end
        end
    end
    return {img, map[1], confidence}
end

function utilities.split(s, sep)
    local sep, fields = sep or ":", {}
    local pattern = string.format("([^%s]+)", sep)
    s:gsub(pattern, function(c) fields[#fields+1] = c end)
    return fields
end

function utilities.coordinateMap(input)
    --[[
       input: b*c*h*w tensor 
       return: b*2*h*w tensor
    --]]
    assert(input:dim() == 4, 'input should be 4D tensor')

    local B, C, H, W = input:size(1), input:size(2), input:size(3), input:size(4)

    local coordinateH = torch.range(0, H-1):div(H-1):add(-0.5):view(H, 1)
    local coordinateW = torch.range(0, W-1):div(W-1):add(-0.5):view(1, W)
    coordinateH = coordinateH:expand(H, W):contiguous():view(1, H, W)
    coordinateW = coordinateW:expand(H, W):contiguous():view(1, H, W)

    local coordinate = torch.cat(coordinateH, coordinateW, 1):view(1, 2, H, W)
    coordinate = coordinate:expand(B, 2, H, W):contiguous()
    coordinate = coordinate:type(input:type())

    coordinate[coordinate:ne(coordinate)] = 0 -- in case H or W == 1
    return coordinate
end

function utilities.getChars(chars)
    local nb_batch = #chars
    local yt = torch.Tensor(nb_batch):fill(0)

    for i = 1, #chars do
        -- assert(#chars[i] == 1, 'chars[i] should only contain 1 char')
        yt[{i}] = chars[i][1].class_index
    end

    yt:add(1) -- important
    return yt
end

function utilities.unpackChars(chars)
    --[[
    params:
        chars: for each char: {name, class_index, rect={}}
               overall: {batch1 = {c1, c2, ...}, batch2 = {}, ...}
    return:
        yt: nb_batch * output_max_len (+1 for EOS)
        bboxes: nb_batch * output_max_len (+1 for EOS) * 4
    --]]
    local nb_batch = #chars
    local output_max_len = 0
    for i = 1, #chars do
        if #chars[i] > output_max_len then output_max_len = #chars[i] end
    end

    local yt = torch.Tensor(nb_batch, output_max_len + 1):fill(0)
    local bboxes = torch.Tensor(nb_batch, output_max_len + 1, 4):fill(0)

    for i = 1, #chars do
        for j = 1, #chars[i] do
            yt[{i, j}] = chars[i][j].class_index
            bboxes[{i, j, 1}] = chars[i][j].rect.minX
            bboxes[{i, j, 2}] = chars[i][j].rect.minY
            bboxes[{i, j, 3}] = chars[i][j].rect.maxX
            bboxes[{i, j, 4}] = chars[i][j].rect.maxY
        end
    end

    yt:add(1) -- important
    return yt, bboxes
end

function utilities.tableSum(T, index)
    --[[
    params:
        T: {{}, {}, {}, ...}
        index:
    return:
        res:
    --]]
    local res = T[1][index]:clone()
    for i = 2, #T do
        res:add(T[i][index])
    end
    return res
end

function utilities.tableMax(T)
    local res = -1000
    for i = 1, #T do
        res = math.max(res, T[i]:max())
    end
    return res
end

function utilities.tableMin(T)
    local res = 1000
    for i = 1, #T do
        res = math.min(res, T[i]:min())
    end
    return res
end

function utilities.getAttentionGT(bboxes, h, w, h_img, w_img)
    --[[
    params:
        bboxes: nb_batch * output_max_len+1 * 4
        h
        w
    return:
        res: {nb_batch * T, nb_batch * T, ...}
    --]]
    
    local res = {}
    local nb_batch = bboxes:size(1)
    local T = bboxes:size(2)
    for i = 1, T do
        local gt = torch.Tensor(nb_batch, h * w)
        local g = torch.Tensor(h, w)
        for j = 1, nb_batch do
            local x0 = math.max(1, math.min(w, math.floor(bboxes[j][i][1] / w_img * w)))
            local y0 = math.max(1, math.min(h, math.floor(bboxes[j][i][2] / h_img * h)))
            local x1 = math.max(1, math.min(w, math.floor(bboxes[j][i][3] / w_img * w)))
            local y1 = math.max(1, math.min(h, math.floor(bboxes[j][i][4] / h_img * h)))
            g:fill(0)
            g[{{y0, y1}, {x0, x1}}]:fill(1)
            g:div(torch.sum(g))
            gt[{j, {}}]:copy(g)
        end
        gt = gt:type(bboxes:type())
        res[i] = gt
    end
    return res
end

function utilities.getAttentionGTGaussian(bboxes, h, w, h_img, w_img)
    --[[
    params:
        bboxes: nb_batch * output_max_len+1 * 4
        h
        w
    return:
        res: {nb_batch * T, nb_batch * T, ...}
    --]]
    
    local res = {}
    local nb_batch = bboxes:size(1)
    local T = bboxes:size(2)
    for i = 1, T do
        local GT = torch.Tensor(nb_batch, h * w)
        local gt = torch.Tensor(h, w)
        for j = 1, nb_batch do
            local x0 = math.max(1, math.min(w, math.floor(bboxes[j][i][1] / w_img * w)))
            local y0 = math.max(1, math.min(h, math.floor(bboxes[j][i][2] / h_img * h)))
            local x1 = math.max(1, math.min(w, math.floor(bboxes[j][i][3] / w_img * w)))
            local y1 = math.max(1, math.min(h, math.floor(bboxes[j][i][4] / h_img * h)))

            local center_x = (x0 + x1) / 2
            local center_y = (y0 + y1) / 2
            local sigma2 = math.max(1, (x1 - x0) + (y1 - y0)) / 2 * 12

            gt:fill(0)
            for y = 1, h do
                local t = torch.range(1, w)
                t:add(-center_x)
                t:pow(2)
                t:div(sigma2)
                t:add((y - center_y) * (y - center_y) / sigma2)
                t:div(-0.5)
                t:exp()
                gt[{y, {}}]:copy(t)
            end
            gt:div(torch.sum(gt))
            GT[{j, {}}]:copy(gt)
        end
        GT = GT:type(bboxes:type())
        res[i] = GT
    end
    res[#res] = res[#res - 1]
    return res
end

function utilities.insertZeroGrad(df_do2, nb_batch, outputSize, T)
    local gradHidden = torch.Tensor(nb_batch, outputSize):type(df_do2[1]:type()):zero()
    local gradAttention = torch.Tensor(nb_batch, T):type(df_do2[1]:type()):zero()
    local df_do2_table = {}
    for i = 1, #df_do2 do
        df_do2_table[i] = {gradHidden, gradAttention, df_do2[i]}
    end
    return df_do2_table
end

function utilities.insertZeroGradAttention(df_do2, df_do3, gradHidden)
    local df_do2_table = {}
    for i = 1, #df_do2 do
        df_do2_table[i] = {gradHidden, df_do3[i], df_do2[i]}
    end
    return df_do2_table
end

return utilities
