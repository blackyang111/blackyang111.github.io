require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'dpnn'

local iChannels

local function create_dilated_conv(c1, c2)
    assert((c2 / 4) == math.floor(c2 / 4), 'c2 should be a multiple of 4')

    local block = nn.Concat(2)
    local c2 = c2 / 4

    local conv1 = nn.Sequential()
    conv1:add(nn.SpatialDilatedConvolution(c1, c2, 3, 3, 1, 1, 1, 1, 1, 1))
    conv1:add(nn.Contiguous())
    conv1:add(cudnn.SpatialBatchNormalization(c2, nil, nil, nil))
    conv1:add(nn.Contiguous())
    block:add(conv1)

    local conv2 = nn.Sequential()
    conv2:add(nn.SpatialDilatedConvolution(c1, c2, 3, 3, 1, 1, 2, 2, 2, 2))
    conv2:add(nn.Contiguous())
    conv2:add(cudnn.SpatialBatchNormalization(c2, nil, nil, nil))
    conv2:add(nn.Contiguous())
    block:add(conv2)

    local conv3 = nn.Sequential()
    conv3:add(nn.SpatialDilatedConvolution(c1, c2, 3, 3, 1, 1, 4, 4, 4, 4))
    conv3:add(nn.Contiguous())
    conv3:add(cudnn.SpatialBatchNormalization(c2, nil, nil, nil))
    conv3:add(nn.Contiguous())
    block:add(conv3)

    local conv4 = nn.Sequential()
    conv4:add(nn.SpatialDilatedConvolution(c1, c2, 3, 3, 1, 1, 8, 8, 8, 8))
    conv4:add(nn.Contiguous())
    conv4:add(cudnn.SpatialBatchNormalization(c2, nil, nil, nil))
    conv4:add(nn.Contiguous())
    block:add(conv4)

    return block
end

local function shortcut(c1, c2, stride)
    if c1 ~= c2 then
        return nn.Sequential()
                :add(cudnn.SpatialConvolution(c1, c2, 1, 1, stride, stride))
                :add(nn.Contiguous())
                :add(cudnn.SpatialBatchNormalization(c2, nil, nil, nil))
                :add(nn.Contiguous())
    elseif stride > 1 then
        return nn.Sequential()
                :add(nn.SpatialAveragePooling(1, 1, stride, stride))
    else
        return nn.Identity()
    end
end

local function basicblock(c, stride, isdilated)
    local c1 = iChannels
    iChannels = c

    local s = nn.Sequential()
    if isdilated then
        s:add(create_dilated_conv(c1, c))
        s:add(cudnn.ReLU(true))
        s:add(cudnn.SpatialConvolution(c, c, 3, 3, stride, stride, 1, 1))
        s:add(nn.Contiguous())
        s:add(cudnn.SpatialBatchNormalization(c, nil, nil, nil))
        s:add(nn.Contiguous())
    else
        s:add(cudnn.SpatialConvolution(c1, c, 3, 3, stride, stride, 1, 1))
        s:add(nn.Contiguous())
        s:add(cudnn.SpatialBatchNormalization(c, nil, nil, nil))
        s:add(nn.Contiguous())
        s:add(cudnn.ReLU(true))
        s:add(cudnn.SpatialConvolution(c, c, 3, 3, 1, 1, 1, 1))
        s:add(nn.Contiguous())
        s:add(cudnn.SpatialBatchNormalization(c, nil, nil, nil))
        s:add(nn.Contiguous())
    end

    return nn.Sequential()
            :add(nn.ConcatTable()
                :add(s)
                :add(shortcut(c1, c, stride)))
            :add(nn.CAddTable(true))
            :add(cudnn.ReLU(true))
end

local function create_model(cout, dropout)
    local model = nn.Sequential()

    model:add(cudnn.SpatialConvolution(1, 64, 3, 3, 1, 1, 1, 1))
    model:add(cudnn.SpatialBatchNormalization(64, nil, nil, nil))
    model:add(cudnn.ReLU())

    iChannels = 64
    model:add(basicblock(128, 1, false))
    model:add(basicblock(128, 1, false))
    model:add(basicblock(128, 2, false))
    model:add(nn.Dropout(dropout or 0.0))

    model:add(basicblock(256, 1, false))
    model:add(basicblock(256, 2, true))
    model:add(nn.Dropout(dropout or 0.0))

    model:add(basicblock(512, 1, false))
    model:add(basicblock(cout or 512, 1, true))

    return model
end

return create_model
