require 'nn'
require 'cutorch'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'dpnn'
require 'optim'
require 'rnn'
require 'image'

require 'BatchIterator_hdf5'

local utilities = require 'utilities'
local pastalog = require 'pastalog'

-- config
local config = dofile('config.lua')
config = config.parse(arg)
print(config)
cutorch.setDevice(config.gpuid)

-- model
local oneHotModel = nn.OneHot(#(config.chars) + 1):cuda()
local encoderModel = dofile('model_encoder.lua')(config.c1out, config.dropout)
local bridgeModel = dofile('model_bridge.lua')(config.c1out)
local decoderModel = dofile('model_decoder.lua')(#config.chars + 1, config.c1out, config.c1out, config.dropout)
local decoderModel_cnn = dofile('model_decoder_cnn.lua')(config.c1out, #config.chars + 1, config.dropout)

-- resume saved model (contains BatchNormalization's running_mean and running_var)
if config.resume_training_trainable > 0 then
    print('loading saved models...')
    local trainable_table = torch.load(config.saved_models)
    encoderModel = trainable_table.encoder
    decoderModel = trainable_table.decoder
    bridgeModel = trainable_table.bridge
    decoderModel_cnn = trainable_table.decoder_cnn
end

-- trainable model
local trainable = nn.Container()
trainable:add(encoderModel)
trainable:add(bridgeModel)
trainable:add(decoderModel)
trainable:add(decoderModel_cnn)
trainable:cuda()
local parameters, gradParameters = trainable:getParameters()

-- resume training
if config.resume_training_optim > 0 then
    print('loading saved optim status...')
    config.optim_state = torch.load(config.saved_optim_state)
end

-- criterion
local criterion = nn.SequencerCriterion(nn.ClassNLLCriterion()):cuda()
local criterion_cnn = nn.CrossEntropyCriterion():cuda()

-- logger
local logger = optim.Logger(config.out_path .. '/logs/log_' .. config.prefix, true)
logger.showPlot = false

-- visualize
local function visualize(H, W, attentions, y, targets, inputs)
    local batch_size = attentions[1]:size(1)
    for n = 1, batch_size do
        for i = 1, #attentions do
            local img = attentions[i][n]:float()
            img:add(-torch.min(img))
            img:div(torch.max(img))
            img = img:view(H, W)
            image.save(string.format('%s/visualize/fcn_attention_%s_%s.jpg', config.out_path, n, i), img)
        end
        local img_original = inputs[n]
        img_original = img_original:float()
        image.save(string.format('%s/visualize/fcn_original_%s.jpg', config.out_path, n), img_original)

        -- decode
        local gt = ''
        local pred = ''
        for i = 1, #y do
            local idx = targets[n] - 1
            if idx == 0 then
                gt = gt .. '_'
            else
                gt = gt .. config.chars[idx]
            end
            local _, idx = torch.max(y[i][n], 1)
            idx = idx[1] - 1
            if idx == 0 then
                pred = pred .. '_'
            else
                pred = pred .. config.chars[idx]
            end
        end
        local fout = io.open(string.format('%s/visualize/fcn_log_%s', config.out_path, n), 'w')
        fout:write(gt .. '#\n' .. pred)
        fout:close()
    end
end

-- pre define
local grad_hidden = torch.Tensor(config.batch_size, config.c1out):cuda():zero()
local grad_attention

-- for pastalog
local step = 0

-- main training
for it_epoch = 1, config.nb_epoch do
    collectgarbage()
    local it_batch = 0
    local batch_iterator = BatchIterator_hdf5(config)
    while not batch_iterator.fullpass do
        it_batch = it_batch + 1
        local batch = batch_iterator:nextBatch('train')

        -- inputs
        local inputs = batch.inputs -- config.batch_size * 1 * 32 * 32
        inputs = inputs:cuda()
        -- targets
        local targets = batch.targets -- config.batch_size
        targets = targets:cuda()

        local function foo()
            local feval = function(x)
                collectgarbage()
                if x ~= parameters then
                    parameters:copy(x)
                end
                gradParameters:zero()

                -- forward
                local features = encoderModel:forward(inputs)
                local outputs = decoderModel_cnn:forward(features)

                -- decoder_cnn loss
                local f_cnn = criterion_cnn:forward(outputs, targets)
                local grad_outputs_cnn = criterion_cnn:backward(outputs, targets)

                -- backward 
                local grad_features_cnn = decoderModel_cnn:backward(features, grad_outputs_cnn)

                local f = 0
                local y, attentions
                if it_epoch > 1 then
                    -- concatenate and resize to a single sequence
                    local features_all = bridgeModel:forward(features) -- nb_batch * (h*w) * c

                    -- prepare input sequence
                    local targets_onehot = oneHotModel:forward(targets):clone()

                    local eos = targets:clone():fill(1)
                    local eos_onehot = oneHotModel:forward(eos)

                    local inputSequence = {}
                    inputSequence[1] = {eos_onehot, features_all}
                    if config.knowledge_distill == 0 then
                        for i = 2, config.decode_max_len do
                            inputSequence[i] = {targets_onehot, features_all} -- targets_onehot is shared
                        end
                    end
                    local targetSequence = {}
                    for i = 1, config.decode_max_len do
                        targetSequence[i] = targets -- targets is shared
                    end

                    -- decoder
                    y = {}
                    attentions = {}

                    decoderModel:forget()
                    for i = 1, config.decode_max_len do
                        y[i] = decoderModel:forward(inputSequence[i])
                        attentions[i] = decoderModel.attention_out
                        -- knowledge distill
                        if config.knowledge_distill ~= 0 then
                            inputSequence[i + 1] = {y[i]:clone(), features_all}
                            inputSequence[i + 1][1]:exp()
                        end
                    end

                    -- decoder loss
                    f = criterion:forward(y, targetSequence) / (#y)
                    local grad_y = criterion:backward(y, targetSequence)

                    -- add grad_hidden and gradAttention
                    local grad_attentions = {}
                    if (not grad_attention) or (not grad_attention:isSameSizeAs(attentions[1])) then
                        grad_attention = attentions[1]:clone():zero()
                    end
                    for i = 1, config.decode_max_len do
                        grad_attentions[i] = grad_attention
                    end

                    local grad_outputSequence = utilities.insertZeroGradAttention(grad_y, grad_attentions, grad_hidden)

                    -- bg decoder
                    local grad_inputSequence = {}
                    for i = #y, 1, -1 do
                        grad_inputSequence[i] = decoderModel:backward(inputSequence[i], grad_outputSequence[i])
                        -- knowledge distill grad
                        if config.knowledge_distill_grad ~= 0 then
                            if i > 1 then
                                grad_outputSequence[i - 1][3]:add(grad_inputSequence[i][1]:cmul(inputSequence[i][1])) -- grad of exp()
                            end
                        end
                    end
                    decoderModel:forget()

                    -- bg bridge
                    local grad_features_all = utilities.tableSum(grad_inputSequence, 2)
                    local grad_features = bridgeModel:backward(features, grad_features_all)

                    -- bg encoder
                    if it_epoch == 2 then
                        encoderModel:backward(inputs, grad_features_cnn)
                    else
                        encoderModel:backward(inputs, grad_features_cnn + grad_features)
                    end
                else
                    -- bg encoder
                    encoderModel:backward(inputs, grad_features_cnn)
                end

                -- print
                if config.debugMode == 1 or it_batch % config.print_iters == 0 then
                    print('it_epoch: ' .. it_epoch .. ' it_batch: ' .. it_batch .. ' loss_cnn: ' .. f_cnn .. ' loss: ' .. f)
                    print(torch.max(gradParameters), torch.min(gradParameters))
                end

                -- visualize attentions and decode
                if it_epoch > 1 and (it_batch % config.vis_iters == 0) then
                    local H, W = features:size(3), features:size(4)
                    visualize(H, W, attentions, y, targets, inputs)
                end

                -- log
                if it_batch % config.log_iters == 0 then
                    logger:add{['loss_cnn'] = f_cnn, ['loss'] = f}
                    if pastalog then
                        step = step + 1
                        pastalog(config.prefix, 'loss_cnn', f_cnn, step)
                        pastalog(config.prefix, 'loss', f, step)
                    end
                end

                -- return
                return f, gradParameters
            end

            -- optimizer
            if config.optimizer == 'sgd' then
                optim.sgd(feval, parameters, config.optim_state)
            elseif config.optimizer == 'rmsprop' then
                optim.rmsprop(feval, parameters, config.optim_state)
            elseif config.optimizer == 'adadelta' then
                optim.adadelta(feval, parameters, config.optim_state)
            else
                optim.adadelta(feval, parameters, config.optim_state)
            end

            -- save
            if it_batch % config.snapshot_iters == 0 then
                print('saving model weight...')
                local filename
                filename = string.format('%s/models/%s_epoch%s_iter%s_%s.t7', config.out_path, config.prefix, it_epoch, it_batch, os.date('_%m.%d_%H.%M'))
                torch.save(filename, parameters)
                filename = string.format('%s/models/%s_epoch%s_iter%s_%s_state.t7', config.out_path, config.prefix, it_epoch, it_batch, os.date('_%m.%d_%H.%M'))
                torch.save(filename, config.optim_state)
                filename = string.format('%s/models/%s_epoch%s_iter%s_%s_config.t7', config.out_path, config.prefix, it_epoch, it_batch, os.date('_%m.%d_%H.%M'))
                torch.save(filename, config)

                print('saving models...')
                filename = string.format('%s/models/%s_epoch%s_iter%s_%s_trainable.t7', config.out_path, config.prefix, it_epoch, it_batch, os.date('_%m.%d_%H.%M'))
                local trainable_table = {encoder=encoderModel:clearState(), decoder=decoderModel:clearState(), bridge=bridgeModel:clearState(), decoder_cnn=decoderModel_cnn:clearState()}
                torch.save(filename, trainable_table)
            end
        end
        if targets:min() > 0 and targets:max() <= (#config.chars + 1) then
            local status, err = pcall(foo)
            if not status then
                print(err)
            end
        end
    end
    -- lr
    if it_epoch % config.lr_decay == 0 then
        config.optim_state.learningRate = config.optim_state.learningRate / config.lr_decay_t
        config.optim_state.learningRate = math.max(config.optim_state.learningRate, config.optim_state.learningRateMin)
        print('decresing lr... new lr: ', config.optim_state.learningRate)
    end
    -- logger:plot('decoder_loss')
end
