require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'

local function create_model(cout, n, dropout)
    local model = nn.Sequential()

    model:add(nn.Dropout(dropout or 0.0))
    model:add(cudnn.SpatialAveragePooling(8, 8, 1, 1, 0, 0))
    model:add(nn.View(cout or 512):setNumInputDims(3))
    model:add(nn.Linear(cout or 512, n))

    return model
end

return create_model
