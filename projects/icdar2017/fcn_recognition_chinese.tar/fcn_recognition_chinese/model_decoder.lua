require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'rnn'
require '../../torch_repo/nn_customized/init.lua'
require '../../torch_repo/nn_customized/GRUAttention.lua'

local function create_model(inputSize, outputSize, featureSize, dropout)
    local model = nn.GRUAttention(inputSize, outputSize, featureSize, dropout)
    return model
end

return create_model
