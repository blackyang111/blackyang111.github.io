# How to run
1. Prepare and download standalone figures, tables, text corpus, captions.
2. Change the path to the downloaded standalone files in main.py.
2. Run run_multiprocess.py
