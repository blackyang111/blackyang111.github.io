require 'nn'
require 'cutorch'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'dpnn'
require 'optim'
require 'rnn'

require 'BatchIterator'
local utilities = require 'utilities'

-- config
local config = dofile('config.lua')
config = config.parse(arg)
print(config)
cutorch.setDevice(config.gpuid)

-- model
local oneHotModel = nn.OneHot(#(config.chars) + 1):cuda()
local splitModel = nn.SplitTable(1, 1):cuda()

local encoderModel = dofile('model_upsample.lua')(#config.classes)
local parameters, gradParameters = encoderModel:getParameters()

-- resume encoder training
if config.resume_training_encoder then
    print('loading saved encoder weight...')
    parameters:copy(torch.load(config.saved_encoder_weights))
end

local bridgeModel = dofile('model_bridge.lua')(config.features_used_channels, config.c1out, 2, config.c2out)

local decoderModel = dofile('model_decoder.lua')(#config.chars + 1, config.c1out + config.c2out, config.c1out + config.c2out)

local trainable = nn.Container()
trainable:add(encoderModel)
trainable:add(bridgeModel)
trainable:add(decoderModel)
trainable:cuda()
local parameters, gradParameters = trainable:getParameters()

-- resume training
if config.resume_training then
    print('loading saved model weight...')
    parameters:copy(torch.load(config.saved_model_weights))
end
if config.resume_training_optim then
    print('loading saved optim status...')
    config.optim_state = torch.load(config.saved_optim_state)
end

-- criterion
local criterion = nn.CrossEntropyCriterion():cuda()
local criterion_decoder = nn.SequencerCriterion(nn.ClassNLLCriterion()):cuda()
local criterion_attention = nn.SequencerCriterion(nn.AbsCriterion()):cuda()

-- dataset
local dataset = torch.load(config.data_file)
local batch_iterator = BatchIterator(config, dataset)

-- main training
for it_img, img_name in ipairs(config.test_img_names) do
    print(it_img)

    -- load img
    local img 
    local function foo()
        img = image.load(img_name, 3)
    end
    local status, err = pcall(foo)

    if status then
        local H, W = img:size(2), img:size(3)
        if H > config.max_height or W > config.max_height then
            img = image.scale(img, config.max_height)
        end
        local h = (math.floor(img:size(2) / 8) + 1) * 8
        local w = (math.floor(img:size(3) / 8) + 1) * 8
        img = image.scale(img, w, h)
        local img_original = img:clone()
        img = img:view(1, img:size(1), img:size(2), img:size(3))
        
        -- inputs and targets
        local inputs = img:cuda()
        print(inputs:size())

        local feval = function(x)
            -- prepare
            collectgarbage()
            if x ~= parameters then
                parameters:copy(x)
            end

            -- output
            local outputs_table = encoderModel:forward(inputs) -- de_feature1(/1), de_feature2(/1), de_feature3(/2), de_feature4(/4)

            -- coordinate map
            local features = outputs_table[config.features_used]:clone()
            local coordinate = utilities.coordinateMap(features)

            -- concatenate and resize to a single sequence
            local features_all = bridgeModel:forward({features, coordinate}) -- nb_batch * (h*w) * c

            local inputSequence = {}
            inputSequence[1] = {torch.CudaTensor(config.batch_size, #(config.chars) + 1):zero(), features_all}

            -- attentive decoderModel
            local y = {}
            local attention = {}

            decoderModel:forget()
            for i = 1, config.decode_max_len do
                y[i] = decoderModel:forward(inputSequence[i])
                attention[i] = decoderModel.attention_out

                local v, idx = y[i]:max(2)
                idx = idx[1][1]
                if idx == 1 then
                    break
                end

                inputSequence[i + 1] = {torch.CudaTensor(config.batch_size, #(config.chars) + 1):zero(), features_all}
                inputSequence[i + 1][1][{1, idx}] = 1
            end

            if it_img % 1 == 0 then
                -- save attention img (FIXME: only support batch_size == 1)
                local H, W = features:size(3), features:size(4)
                for i = 1, #attention do
                    local img = attention[i]:float()
                    img:add(-torch.min(img))
                    img:div(torch.max(img))
                    img = img:view(H, W)
                    image.save(string.format('test/%s_%s_fcn_attention_%s.jpg', config.prefix, it_img, i), img)
                end
                image.save(string.format('test/%s_%s_fcn_original.jpg', config.prefix, it_img), img_original)

                -- decode
                local gt = ''
                local pred = ''
                for i = 1, #y do
                    local _, idx = torch.max(y[i], 2)
                    idx = idx[1][1] - 1
                    if idx == 0 then
                        pred = pred .. '_'
                    else
                        pred = pred .. config.chars[idx]
                    end
                end
                local fout = io.open(string.format('test/%s_%s_fcn_log', config.prefix, it_img), 'w')
                fout:write(string.format('%s # %s\n', gt, pred))
                fout:write(string.format('%s, %s, %s\n', f, f2, f3))
                fout:close()
            end

            -- return
            local f = 0
            return f, gradParameters
        end

        -- manual mini-batch
        local fx, dfdx = feval(parameters)
    else
        print(err)
    end
end
