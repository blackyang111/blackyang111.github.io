require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'

local function create_conv(c1, c2)
    local conv = nn.Sequential()
    conv:add(cudnn.SpatialConvolution(c1, c2, 1, 1, 1, 1, 0, 0, 1))
    conv:add(cudnn.ReLU(true))
    conv:add(cudnn.SpatialConvolution(c2, c2, 1, 1, 1, 1, 0, 0, 1))
    conv:add(cudnn.SpatialBatchNormalization(c2, nil, nil, nil))
    return conv
end

local function create_model(c1in, c1out, c2in, c2out)
    local model = nn.Sequential()

    local p = nn.ParallelTable()
    p:add(nn.Identity())
    p:add(create_conv(c2in, c2out))

    model:add(p)
    model:add(nn.JoinTable(1, 3))
    model:add(nn.Transpose({2, 3}, {3, 4}))
    model:add(nn.View(-1, c1out + c2out):setNumInputDims(3))
    return model
end

return create_model
