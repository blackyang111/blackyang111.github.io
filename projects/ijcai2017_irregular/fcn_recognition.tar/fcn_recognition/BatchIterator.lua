require 'image'
require 'utilities'
require 'LuaXML'
local ffi = require 'ffi'

local BatchIterator = torch.class('BatchIterator')

function BatchIterator:__init(config, dataset)
    self.batch_size = config.batch_size or 128
    self.pixel_means = config.pixel_means or {0, 0, 0}
    self.max_height = config.max_height or 512

    self.classes = config.classes
    self.classes_index = {}
    for i, v in ipairs(self.classes) do
        self.classes_index[v] = i
    end
    self.chars = config.chars
    self.chars_index = {}
    for i, v in ipairs(self.chars) do
        self.chars_index[v] = i
    end


    self.img_path = config.img_path
    self.xml_path = config.xml_path

    -- dataset: {img_names = torch.CharTensor(), xml_names = torch.CharTensor()}
    self.data = dataset

    self.train = {}
    self.val = {}
    self.test = {}

    local length = self.data['img_names']:size(1)
    local order = torch.randperm(length)
    self.train.data = order[{{1, math.floor(length * 0.9)}}]
    self.val.data = order[{{math.floor(length * 0.9), length}}]
    self.test.data = order[{{math.floor(length * 0.9), length}}]

    -- order
    self.train.order = torch.randperm(self.train.data:size(1))
    self.val.order = torch.randperm(self.val.data:size(1))
    self.test.order = torch.randperm(self.test.data:size(1))
end

function BatchIterator:setBatchSize(batch_size)
    self.batch_size = batch_size or 128
end

function BatchIterator:nextEntry(set)
    local i = self[set].i or 1
    self[set].i = i + 1
    
    -- re shuffle
    if i > self[set].data:size(1) then
        self[set].order = torch.randperm(self[set].data:size(1))
        i = 1
    end

    local index = self[set].order[i]
    local index_true = self[set].data[index]

    local img_name = ffi.string(self.data['img_names'][index_true]:data())
    local xml_name = ffi.string(self.data['xml_names'][index_true]:data())
    return {self.img_path .. img_name, self.xml_path .. xml_name}
end

function BatchIterator:nextBatch(set)
    local batch = {}
    batch.inputs = {}
    batch.targets = {}
    batch.images = {}
    batch.chars = {}

    for i = 1, self.batch_size do
        -- get entry (img_path_full, xml_path_full)
        local entry = self:nextEntry(set)

        -- img
        local img = image.load(entry[1], 3)
        local H, W = img:size(2), img:size(3)
        table.insert(batch.images, img)

        -- rescale if too large
        if H > self.max_height or W > self.max_height then
            img = image.scale(img, self.max_height)
        end

        local h = math.floor(img:size(2) / 8) * 8
        local w = math.floor(img:size(3) / 8) * 8
        img = image.scale(img, w, h)

        local scale_h = h / H
        local scale_w = w / W

        -- subtract mean
        for ch = 1, 3 do
            if math.max(unpack(self.pixel_means)) < 1 then
                img[{ch, {}, {}}]:add(-self.pixel_means[ch])
            else
                img[{ch, {}, {}}]:add(-self.pixel_means[ch] / 255)
            end
        end
        table.insert(batch.inputs, img)

        -- target rois
        local rois = {}
        local chars = {}
        local xml_file = xml.load(entry[2])
        for _,objs in pairs(xml_file) do
            if xml.find(objs,'object') then
                local roi = {}
                local char = {}
                for i,obj in ipairs(objs) do
                    local name = obj:find('name')
                    if name then
                        roi.name = name[1]
                        roi.class_index = self.classes_index['__foreground__']
                        char.name = name[1]
                        char.class_index = self.chars_index[name[1]]
                    end
                    
                    local bbox = obj:find('bndbox')
                    if bbox then
                        roi.rect = {}
                        roi.rect.minX = tonumber(bbox:find('xmin')[1])
                        roi.rect.maxX = tonumber(bbox:find('xmax')[1])
                        roi.rect.minY = tonumber(bbox:find('ymin')[1])
                        roi.rect.maxY = tonumber(bbox:find('ymax')[1])
                        char.rect = {}
                        char.rect.minX = tonumber(bbox:find('xmin')[1])
                        char.rect.maxX = tonumber(bbox:find('xmax')[1])
                        char.rect.minY = tonumber(bbox:find('ymin')[1])
                        char.rect.maxY = tonumber(bbox:find('ymax')[1])
                    end
                end
                table.insert(rois, roi)
                table.insert(chars, char)
            end
        end
        table.insert(batch.chars, chars)

        -- target
        local rescale = 1
        local target = torch.Tensor(math.floor(img:size(2) / rescale), math.floor(img:size(3) / rescale)):fill(1) -- 1 for background
        local ht, wt = target:size(1), target:size(2)
        for i, roi in ipairs(rois) do
            local minX, minY, maxX, maxY = roi.rect.minX, roi.rect.minY, roi.rect.maxX, roi.rect.maxY
            minX = math.floor(minX * scale_w / rescale)
            minX = math.min(wt, (math.max(minX, 1)))

            minY = math.floor(minY * scale_h / rescale)
            minY = math.min(ht, (math.max(minY, 1)))

            maxX = math.floor(maxX * scale_w / rescale)
            maxX = math.min(wt, (math.max(maxX, 1)))

            maxY = math.floor(maxY * scale_h / rescale)
            maxY = math.min(ht, (math.max(maxY, 1)))
            local class_index = roi.class_index
            target[{{minY, maxY}, {minX, maxX}}]:fill(class_index)
        end
        table.insert(batch.targets, target)
    end

    -- format input
    local ch, h, w
    ch, h, w= batch.inputs[1]:size(1), batch.inputs[1]:size(2), batch.inputs[1]:size(3)
    batch.inputs= torch.cat(batch.inputs):view(self.batch_size, ch, h, w)

    -- format target
    ch, h, w = 1, batch.targets[1]:size(1), batch.targets[1]:size(2)
    batch.targets = torch.cat(batch.targets):view(self.batch_size, ch, h, w)

    -- return
    return batch
end
