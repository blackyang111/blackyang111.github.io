require 'nn'
require 'cutorch'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'dpnn'
require 'optim'
require 'rnn'

require 'BatchIterator'
local utilities = require 'utilities'

-- config
local config = dofile('config.lua')
config = config.parse(arg)
print(config)
cutorch.setDevice(config.gpuid)

-- model
local oneHotModel = nn.OneHot(#(config.chars) + 1):cuda()
local splitModel = nn.SplitTable(1, 1):cuda()

local encoderModel = dofile('model_upsample.lua')(#config.classes)
local parameters, gradParameters = encoderModel:getParameters()

-- resume encoder training
if config.resume_training_encoder then
    print('loading saved encoder weight...')
    parameters:copy(torch.load(config.saved_encoder_weights))
end

local bridgeModel = dofile('model_bridge.lua')(config.features_used_channels, config.c1out, 2, config.c2out)

local decoderModel = dofile('model_decoder.lua')(#config.chars + 1, config.c1out + config.c2out, config.c1out + config.c2out)

local trainable = nn.Container()
trainable:add(encoderModel)
trainable:add(bridgeModel)
trainable:add(decoderModel)
trainable:cuda()
local parameters, gradParameters = trainable:getParameters()

-- resume training
if config.resume_training then
    print('loading saved model weight...')
    parameters:copy(torch.load(config.saved_model_weights))
end
if config.resume_training_optim then
    print('loading saved optim status...')
    config.optim_state = torch.load(config.saved_optim_state)
end

-- criterion
local criterion = nn.CrossEntropyCriterion():cuda()
local criterion_decoder = nn.SequencerCriterion(nn.ClassNLLCriterion()):cuda()
local criterion_attention = nn.SequencerCriterion(nn.MSECriterion()):cuda()

-- dataset
local dataset = torch.load(config.data_file)
local batch_iterator = BatchIterator(config, dataset)

-- logger
local logger = optim.Logger(config.log_path .. 'log', true)
logger.showPlot = false

-- confusion matrix
local confusion = optim.ConfusionMatrix(config.classes)

-- main training
local f_table = {}
local gradParameters_table = {}

for it_batch = config.snapshot_iters_start + 1, config.snapshot_iters_start + math.floor(config.nb_epoch * batch_iterator.train.data:size(1) / config.batch_size) do
    local batch = batch_iterator:nextBatch('train')

    -- inputs and targets
    local inputs = batch.inputs
    inputs = inputs:cuda()

    local targets = batch.targets
    targets = targets:cuda()
    targets = targets:view(-1, 1)

    local feval = function(x)
        -- prepare
        collectgarbage()
        if x ~= parameters then
            parameters:copy(x)
        end

        -- output
        local outputs_table = encoderModel:forward(inputs) -- de_feature1(/1), de_feature2(/1), de_feature3(/2), de_feature4(/4)

        local f = 0
        local df_do = outputs_table[1]:clone():zero()

        local outputs = outputs_table[1]:clone()
        local ch, h, w = outputs:size(2), outputs:size(3), outputs:size(4)

        outputs = outputs:permute(1, 3, 4, 2):contiguous()
        outputs= outputs:view(-1, ch)
        confusion:batchAdd(outputs, targets)

        -- coordinate map
        local features = outputs_table[config.features_used]:clone()
        local coordinate = utilities.coordinateMap(features)

        -- concatenate and resize to a single sequence
        local features_all = bridgeModel:forward({features, coordinate}) -- nb_batch * (h*w) * c

        -- prepare input sequence
        local yt, bboxes = utilities.unpackChars(batch.chars) -- nb_batch * output_max_len (+1 for EOS); nb_batch * output_max_len * 4
        yt = yt:cuda()
        bboxes = bboxes:cuda()
        local yt_split = splitModel:forward(yt)

        local inputSequence = {}
        inputSequence[1] = {oneHotModel:forward(yt_split[#yt_split]):clone(), features_all}
        for i = 2, yt:size(2) do
            inputSequence[i] = {oneHotModel:forward(yt_split[i - 1]):clone(), features_all}
        end

        -- prepare attention sequence
        local attention_gt = utilities.getAttentionGTGaussian(bboxes, features:size(3), features:size(4), batch.images[1]:size(2), batch.images[1]:size(3))

        -- attentive decoderModel
        local y = {}
        local attention = {}

        decoderModel:forget()
        for i = 1, #inputSequence do
            y[i] = decoderModel:forward(inputSequence[i])
            attention[i] = decoderModel.attention_out
        end

        -- attentive decoderModel loss
        local f2 = criterion_decoder:forward(y, yt_split) / (#y)
        local df_do2 = criterion_decoder:backward(y, yt_split)

        -- attentive decoderModel attention loss
        local f3 = criterion_attention:forward(attention, attention_gt) / (#attention)
        local df_do3 = criterion_attention:backward(attention, attention_gt)
        df_do3[#df_do3]:zero()

        -- attention loss weight
        f3 = f3 * config.attention_loss_weight
        for i = 1, #df_do3 do
            df_do3[i]:mul(config.attention_loss_weight)
        end

        -- add gradHidden and gradAttention
        local df_do2_table = utilities.insertZeroGradAttention(df_do2, df_do3, config.batch_size, config.c1out + config.c2out)

        -- bg
        gradParameters:zero()

        -- bg decoder
        local grad_inputSequence = {}
        for i = #y, 1, -1 do
            grad_inputSequence[i] = decoderModel:backward(inputSequence[i], df_do2_table[i])
        end
        decoderModel:forget()

        -- bg bridge
        local grad_features_all = utilities.tableSum(grad_inputSequence, 2)
        local grad_features, grad_coordinate = unpack(bridgeModel:backward({features, coordinate}, grad_features_all))

        -- decoder loss weight
        -- grad_features:div(config.decoder_loss_weight)

        -- bg encoder
        local grad_features_table = {df_do, outputs_table[2]:clone():zero(), outputs_table[3]:clone():zero(), outputs_table[4]:clone():zero()}
        grad_features_table[config.features_used] = grad_features
        encoderModel:backward(inputs, grad_features_table)

        -- print
        if it_batch % (config.print_iters * config.batch_size_real) == 0 then
            print(it_batch, f, f2, f3)
            print(utilities.tableMax(df_do2), utilities.tableMin(df_do2), utilities.tableMax(df_do3), utilities.tableMin(df_do3), torch.max(gradParameters), torch.min(gradParameters))
        end

        if it_batch % config.vis_iters == 0 then
            -- save attention img (FIXME: only support batch_size == 1)
            local H, W = features:size(3), features:size(4)
            for i = 1, #attention do
                local img = attention[i]:float()
                img:add(-torch.min(img))
                img:div(torch.max(img))
                img = img:view(H, W)
                image.save(string.format('debug/fcn_attention_%s.jpg', i), img)
                local img = attention_gt[i]:float()
                img:add(-torch.min(img))
                img:div(torch.max(img))
                img = img:view(H, W)
                image.save(string.format('debug/fcn_attention_gt_%s.jpg', i), img)
            end
            image.save('debug/fcn_original.jpg', batch.images[1])

            -- decode
            local gt = ''
            local pred = ''
            for i = 1, #inputSequence do
                local idx = yt[{1, i}] - 1
                if idx == 0 then
                    gt = gt .. '_'
                else
                    gt = gt .. config.chars[idx]
                end
                local _, idx = torch.max(y[i], 2)
                idx = idx[1][1] - 1
                if idx == 0 then
                    pred = pred .. '_'
                else
                    pred = pred .. config.chars[idx]
                end
            end
            local fout = io.open('debug/fcn_log', 'w')
            fout:write(gt .. '#' .. pred)
            fout:close()
        end

        -- log
        if it_batch % config.log_iters == 0 then
            logger:add{['training_loss'] = f, ['training_loss2'] = f2, ['training_loss3'] = f3}
        end

        -- return
        return f2, gradParameters
    end

    -- manual mini-batch
    local fx, dfdx = feval(parameters)
    table.insert(f_table, fx)
    table.insert(gradParameters_table, dfdx:clone())

    -- optimizer
    if it_batch % config.batch_size_real == 0 then
        local feval2 = function(x)
            collectgarbage()
            if x ~= parameters then
                parameters:copy(x)
            end

            local f = torch.sum(torch.Tensor(f_table)) / (#f_table)
            print('average loss', f)

            local g = gradParameters:clone():zero()
            for i = 1, #gradParameters_table do
                g:add(gradParameters_table[i])
            end
            gradParameters:copy(g)
            gradParameters:div(#gradParameters_table)

            return f, gradParameters
        end
        optim.adadelta(feval2, parameters, config.optim_state)
        f_table = {}
        gradParameters_table = {}
    end

    -- save
    if it_batch % config.snapshot_iters == 0 then
        print('saving model weight...')
        local filename
        filename = config.model_path .. config.prefix .. 'iter_' .. it_batch .. os.date('_%m.%d_%H.%M') .. '.t7'
        torch.save(filename, parameters)
        filename = config.model_path .. config.prefix .. 'iter_' .. it_batch .. os.date('_%m.%d_%H.%M') .. '_state.t7'
        torch.save(filename, config.optim_state)
    end

    -- confusion
    if it_batch % config.confusion_iters == 0 then
        confusion:updateValids()
        print(config.classes)
        print(string.format('training confusion matrix: %s',tostring(confusion)))
        confusion:zero()
    end

    -- lr
    if it_batch % config.lr_decay == 0 then
        config.optim_state.learningRate = config.optim_state.learningRate / config.lr_decay_t
        config.optim_state.learningRate = math.max(config.optim_state.learningRate, config.optim_state.learningRateMin)
        print('decresing lr... new lr:', config.optim_state.learningRate)
    end
end
