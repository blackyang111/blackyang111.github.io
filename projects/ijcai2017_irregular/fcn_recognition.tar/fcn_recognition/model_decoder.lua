require 'nn'
require 'cunn'
require 'cudnn'
require 'nngraph'
require 'rnn'
require '../../torch_repo/nn_customized/init.lua'
require '../../torch_repo/nn_customized/GRUAttention_sharp.lua'

local function create_model(inputSize, outputSize, featureSize)
    local model = nn.GRUAttention(inputSize, outputSize, featureSize)
    return model
end

return create_model
