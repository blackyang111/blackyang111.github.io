local ffi = require 'ffi'

local function create_traindata_pascal(data_path, img_list, set_folder, img_folder, xml_folder, cache_path, out_name)
    local img_list = string.format('%s/%s/%s', data_path, set_folder, img_list)   
    assert(path.exists(img_list), 'img list not exist')

    -- get count and max_length
    local count = 0
    local max_length = 0
    local fin = io.open(img_list, 'r')
    for line in fin:lines() do
        count = count + 1
        max_length = math.max(max_length, #line)
    end
    fin:close()
    print('number of training data: ', count)
    print('max path length: ', max_length)

    -- CharTensor
    local img_names = torch.CharTensor(count, max_length + 1):fill(0) -- +1 is important! c-like string need to have 0 as end
    local xml_names = torch.CharTensor(count, max_length + 1):fill(0)

    -- main
    local N = img_names:size(1)
    local count = 1
    local fin = io.open(img_list, 'r')
    for line in fin:lines() do
        ffi.copy(img_names[count]:data(), line)

        local p, _ = string.match(line, '(.+)%.(.+)')
        ffi.copy(xml_names[count]:data(), p .. '.xml')

        count = count + 1
        if count % 10000 == 0 then
            xlua.progress(count, N)
        end
    end
    fin:close()

    -- save
    local outputs = {img_names = img_names, xml_names = xml_names}
    local outputs_path = string.format('%s/%s', cache_path, out_name)
    torch.save(outputs_path, outputs)
    print('\nDone.')
end

local data_path = './data/synthetic_sequence_orient_v2/'
local img_list = 'trainval.txt'
local set_folder = 'ImageSets'
local img_folder = 'JPEGImages'
local xml_folder = 'Annotations'

local cache_path = './cache/'
local out_name = 'synthetic_sequence_orient_v2.t7'
create_traindata_pascal(data_path, img_list, set_folder, img_folder, xml_folder, cache_path, out_name, img_name_maxlength)
