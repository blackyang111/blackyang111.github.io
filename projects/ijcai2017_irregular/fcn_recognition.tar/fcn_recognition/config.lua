--- All parameters goes here
local config = config or {}

function config.parse(arg)
	local cmd = torch.CmdLine()
	cmd:text()
	cmd:text('Adaptive classification')
	cmd:text()
	-- Parameters
    -- data loader
    cmd:option('-prefix', 'synthetic_caption_', 'prefix: dataset name')
    cmd:option('-max_height', 384, 'img max height')
	cmd:option('-pixel_means', {128, 128, 128}, 'Pixel mean values (RGB order)')

    cmd:option('-data_file', '../faster-rcnn.torch/pdf_synthetic_caption.t7', 'data path')
    cmd:option('-img_path', './data/synthetic_sequence_orient_v3/JPEGImages/', 'img path')
    cmd:option('-xml_path', './data/synthetic_sequence_orient_v3/Annotations/', 'xml path')
    cmd:option('-cache_path', './cache/', 'cache path')

    -- training and testing
    cmd:option('-gpuid', 1, 'gpu id')
    cmd:option('-optim_state', {rho=0.5, eps=1e-6, learningRate=1e-3, learningRateMin=1e-6, momentum=0.9}, 'optim state')
    cmd:option('-lr_decay', 50000, 'iterations between lr decreses')
    cmd:option('-lr_decay_t', 2, 'lr decay times')
    cmd:option('-nb_epoch', 50, 'number of epoches')
    cmd:option('-batch_size', 1, 'batch size')
    cmd:option('-test_img', 'test/1.jpg', 'test image path')
    cmd:option('-have_class_weights', false, 'whether having class_weights or not')

    cmd:option('-features_used', 5, 'feature maps used')
    cmd:option('-features_used_channels', 512, 'channels of the feature maps used')
    cmd:option('-c1out', 512, 'c1out') -- should be same as c1in since using nn.Identity()
    cmd:option('-c2out', 64, 'c2out')

    cmd:option('-decoder_loss_weight', 1, 'weight of decoder loss')
    cmd:option('-attention_loss_weight', 1000, 'weight of decoder loss')
    cmd:option('-batch_size_real', 64, 'real batch size (avg gradParameters every batch_size_real)')

    -- resume
    cmd:option('-resume_training', false, 'whether resume training')
    cmd:option('-saved_model_weights', './models/synthetic_deconv2_iter_130000_07.25_16.58.t7', 'path to saved model weights')

    cmd:option('-resume_training_optim', false, 'whether resume training')
    cmd:option('-saved_optim_state', './models/synthetic_deconv2_iter_130000_07.25_16.58.t7', 'path to saved model weights')

    cmd:option('-resume_training_encoder', false, 'whether resume training')
    cmd:option('-saved_encoder_weights', './models/synthetic_deconv2_iter_130000_07.25_16.58.t7', 'path to saved model weights')

    -- save/print/log
	cmd:option('-snapshot_iters', 10000, 'Iterations between snapshots (used for saving the network)')
    cmd:option('-snapshot_iters_start', 0, 'number of iteration where we start from')
	cmd:option('-print_iters', 1, 'Iterations between print')
	cmd:option('-log_iters', 20, 'Iterations between log')
	cmd:option('-vis_iters', 200, 'Iterations between visualization')
	cmd:option('-confusion_iters', 200, 'Iterations between confusion matrix')
	cmd:option('-model_path','./models/','Path to be used for saving the trained models')
	cmd:option('-log_path','./logs/','Path to be used for logging')

    cmd:option('-val_size', 200, 'size of val set')
    cmd:option('-test_img_list', '', 'test img names')
    cmd:option('-decode_max_len', 20, 'decode max len')

	-- Parsing the command line 
	config = cmd:parse(arg or {})

    -- other config
    config.colors = {{0, 0, 0}, -- black 
                     {1, 0, 0}, -- red
                     {0, 1, 0}, -- green
                     {0, 0, 1}, -- blue
                     {1, 1, 0}, -- yellow
                     {1, 0, 1}, -- magenta
                     {0, 1, 1}, -- cyan
                     {1, 1, 1}  -- white
                    }

    config.class_weights = {10000/2071109637,
                            10000/81518384,
                            10000/177951017,
                            10000/156450436,
                            10000/375301594,
                            10000/44197636,
                            10000/420447296}

    config.classes = {'__background__', '__foreground__'} -- used when creating traindata.t7 file
    config.chars = {}
    local charset = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    for i = 1, #charset do
        table.insert(config.chars, charset:sub(i, i))
    end

    config.test_img_names = {}
    if path.exists(config.test_img_list) then
        for line in io.lines(config.test_img_list) do
            table.insert(config.test_img_names, line)
        end
    end

	return config
end

return config
